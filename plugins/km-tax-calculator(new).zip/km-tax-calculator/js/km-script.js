jQuery(document).ready(function($) {

    // ========================================
    // REGULAR CALCULATOR FUNCTIONALITY
    // ========================================
    
    // Salary update for regular calculator
    $(document).on("input", "#km_salary", function() {
        var val = parseInt($(this).val());
        $("#km_salary_val").text("$" + val.toLocaleString());
    });

    // Regular calculator tabs - completely isolated
    $(".km-regular-tab").click(function() {
        // Only affect tabs within the same calculator
        var $calculator = $(this).closest(".km-calculator-wrapper");
        
        // Remove active class from all regular tabs in this calculator
        $calculator.find(".km-regular-tab").removeClass("km-active");
        
        // Add active class to clicked tab
        $(this).addClass("km-active");
        
        // Store active tab type
        $calculator.data("active-tab", $(this).data("tab"));
        
        // Reset form for regular calculator
        resetRegularForm($calculator);
        
        // Clear any active results
        var $formContent = $calculator.find("#km-form-content");
        var $resultContent = $calculator.find("#km-result-content");
        
        if ($resultContent.hasClass("show")) {
            $resultContent.removeClass("show");
            setTimeout(function() {
                $formContent.removeClass("hide");
            }, 300);
        }
    });

    // Calculate button for regular calculator
    $("#km_calculate_btn").click(function() {
        var $calculator = $(this).closest(".km-calculator-wrapper");
        var salary = parseFloat($("#km_salary").val());
        var years = parseFloat($("#km_years").val());
        var industry = $("#km_industry").val();
        var activeTab = $calculator.data("active-tab") || "paye";

        // Validation
        if (!industry) {
            alert("Please select your industry");
            return;
        }
        
        if (!years || isNaN(years)) {
            alert("Please select number of years");
            return;
        }
        
        if (!salary || salary < 18000) {
            alert("Please enter a valid salary (minimum £18,000)");
            return;
        }

        // Calculate refund based on multiple factors
        var refund = calculateRefundAmount(salary, years, industry, activeTab);
        var formatted = "$" + refund.toLocaleString();

        $("#km_refund_amount").text(formatted);
        
        // Animate transition
        var $formContent = $("#km-form-content");
        var $resultContent = $("#km-result-content");
        
        $formContent.addClass("hide");
        
        setTimeout(function() {
            $resultContent.addClass("show");
        }, 300);
    });

    // Clear button for regular calculator
    $("#km_clear_btn").click(function() {
        var $calculator = $(this).closest(".km-calculator-wrapper");
        var $resultContent = $("#km-result-content");
        var $formContent = $("#km-form-content");
        
        $resultContent.removeClass("show");
        
        setTimeout(function() {
            $formContent.removeClass("hide");
            resetRegularForm($calculator);
        }, 300);
    });

    // Reset function for regular calculator
    function resetRegularForm($calculator) {
        $("#km_salary").val(18000);
        $("#km_salary_val").text("$18,000");
        $("#km_years").val("");
        $("#km_industry").val("");
        $("#km_refund_amount").text("$0");
        
        // Reset to default values if needed
        if ($calculator && $calculator.data("active-tab") === "cis") {
            // CIS specific reset if needed
            console.log("CIS calculator reset");
        }
    }

    // ========================================
    // INLINE CALCULATOR FUNCTIONALITY
    // ========================================
    
    // Salary update for inline calculator
    $(document).on("input", "#km_inline_salary", function() {
        var val = parseInt($(this).val());
        $(this).closest(".km-field").find("#km_inline_salary_val").text("$" + val.toLocaleString());
    });

    // Inline calculator tabs - completely isolated
    $(".km-inline-tab").click(function() {
        // Only affect tabs within the same inline calculator
        var $wrapper = $(this).closest(".km-inline-wrapper");
        
        // Remove active class from all inline tabs in this wrapper
        $wrapper.find(".km-inline-tab").removeClass("km-active");
        
        // Add active class to clicked tab
        $(this).addClass("km-active");
        
        // Store active tab type
        $wrapper.data("active-tab", $(this).data("tab"));
        
        // Auto-calculate when tab changes
        calculateInlineRefund($wrapper);
    });

    // Inline auto calculation on input changes
    $(document).on("input change", ".km-inline-industry, .km-inline-years, #km_inline_salary", function() {
        var $wrapper = $(this).closest(".km-inline-wrapper");
        
        if (!$wrapper.length) return;
        
        calculateInlineRefund($wrapper);
    });

    // Calculate inline refund
    function calculateInlineRefund($wrapper) {
        var salary = parseFloat($wrapper.find("#km_inline_salary").val());
        var years = parseFloat($wrapper.find(".km-inline-years").val());
        var industry = $wrapper.find(".km-inline-industry").val();
        var activeTab = $wrapper.data("active-tab") || "paye";
        
        // Update salary display
        $wrapper.find("#km_inline_salary_val").text("$" + salary.toLocaleString());
        
        // Validation
        if (!years || isNaN(years) || !industry || !salary) {
            $wrapper.find(".km-inline-result").text("$0");
            return;
        }
        
        // Calculate refund
        var refund = calculateRefundAmount(salary, years, industry, activeTab);
        var formatted = "$" + refund.toLocaleString();
        
        $wrapper.find(".km-inline-result").text(formatted);
    }

    // Clear button for inline calculator
    $(document).on("click", "#km_inline_clear", function() {
        var $wrapper = $(this).closest(".km-inline-wrapper");
        resetInlineForm($wrapper);
    });

    // Reset function for inline calculator
    function resetInlineForm($wrapper) {
        $wrapper.find("#km_inline_salary").val(18000);
        $wrapper.find("#km_inline_salary_val").text("$18,000");
        $wrapper.find(".km-inline-years").val("");
        $wrapper.find(".km-inline-industry").val("");
        $wrapper.find(".km-inline-result").text("$0");
        
        // Reset to PAYE tab by default
        $wrapper.find(".km-inline-tab").removeClass("km-active");
        $wrapper.find(".km-inline-tab[data-tab='paye']").addClass("km-active");
        $wrapper.data("active-tab", "paye");
    }

    // ========================================
    // COMMON CALCULATION FUNCTION
    // ========================================
    
    function calculateRefundAmount(salary, years, industry, tabType) {
        // Base calculation percentage
        let basePercentage = 0.04; // 4% base refund rate
        
        // Adjust based on salary brackets
        let adjustedPercentage = basePercentage;
        
        if (salary <= 25000) {
            adjustedPercentage = 0.045; // 4.5% for lower income
        } else if (salary <= 50000) {
            adjustedPercentage = 0.042; // 4.2% for medium income
        } else if (salary <= 75000) {
            adjustedPercentage = 0.04; // 4% for upper medium
        } else if (salary <= 100000) {
            adjustedPercentage = 0.038; // 3.8% for high income
        } else {
            adjustedPercentage = 0.035; // 3.5% for very high income
        }
        
        // Calculate base refund
        let refund = salary * adjustedPercentage * years;
        
        // Industry adjustments
        switch(industry) {
            case 'construction-trades':
                refund = refund * 1.12; // 12% bonus for construction
                break;
            case 'healthcare-care':
                refund = refund * 1.05; // 5% bonus for healthcare
                break;
            case 'recruitment':
                refund = refund * 1.08; // 8% bonus for recruitment
                break;
            case 'travel-airlines':
                refund = refund * 1.1; // 10% bonus for travel
                break;
            case 'public-sector':
                refund = refund * 1.03; // 3% bonus for public sector
                break;
            case 'property-real-estate':
                refund = refund * 1.07; // 7% bonus for property
                break;
            default:
                // Other industry - standard calculation
                refund = refund * 1.0;
        }
        
        // Tab type adjustments
        if (tabType === 'cis') {
            refund = refund * 1.15; // 15% bonus for CIS
        }
        
        // Ensure minimum refund amount
        if (refund < 500 && refund > 0) {
            refund = 500;
        }
        
        // Round to nearest integer
        return Math.round(refund);
    }

    // ========================================
    // MOBILE OPTIMIZATION
    // ========================================
    
    // Handle mobile touch events for better UX
    if ('ontouchstart' in window) {
        $('.km-tab, .km-btn, .km-claim-btn, .km-clear-link').on('touchstart', function() {
            $(this).trigger('focus');
        });
        
        // Prevent zoom on input focus for mobile
        $('input, select').on('focus', function() {
            if (window.innerWidth <= 768) {
                document.body.style.fontSize = '16px';
            }
        });
    }
    
    // Handle window resize for responsive adjustments
    $(window).on('resize', function() {
        if ($(window).width() <= 768) {
            // Mobile specific adjustments
            $('.km-content').css({
                'position': 'relative',
                'height': 'auto'
            });
        } else {
            // Desktop adjustments
            $('.km-content').css({
                'position': 'absolute',
                'height': ''
            });
        }
    });
    
    // Trigger resize on load
    $(window).trigger('resize');
    
    // ========================================
    // CLAIM BUTTON FUNCTIONALITY
    // ========================================
    
    // Claim button for regular calculator
    $(document).on("click", ".km-claim-btn", function() {
        var $calculator = $(this).closest(".km-calculator-wrapper, .km-inline-wrapper");
        var refundAmount = $calculator.find(".refund-amount, .km-inline-result").text();
        var industry = $calculator.find("#km_industry, .km-inline-industry").val();
        var years = $calculator.find("#km_years, .km-inline-years").val();
        var salary = $calculator.find("#km_salary, #km_inline_salary").val();
        var tabType = $calculator.data("active-tab") || "paye";
        
        // Log claim data
        console.log("Claim initiated:", {
            refund: refundAmount,
            industry: industry,
            years: years,
            salary: salary,
            tab: tabType
        });
        
        // You can replace this with actual form submission or redirect
        // alert("Thank you for your interest! Our team will contact you shortly to process your claim of " + refundAmount);
        
        // Optional: Redirect to contact page
        // window.location.href = "/claim?refund=" + encodeURIComponent(refundAmount);
    });
    
    // ========================================
    // INITIALIZATION
    // ========================================
    
    // Set default values on page load
    function initCalculators() {
        // Regular calculator
        if ($("#km_salary").length) {
            $("#km_salary").val(18000);
            $("#km_salary_val").text("$18,000");
        }
        
        // Inline calculator
        if ($("#km_inline_salary").length) {
            $("#km_inline_salary").val(18000);
            $("#km_inline_salary_val").text("$18,000");
        }
        
        // Set active tab for regular calculator
        $(".km-regular-tab.km-active").each(function() {
            var $calc = $(this).closest(".km-calculator-wrapper");
            $calc.data("active-tab", $(this).data("tab"));
        });
        
        // Set active tab for inline calculator
        $(".km-inline-tab.km-active").each(function() {
            var $wrapper = $(this).closest(".km-inline-wrapper");
            $wrapper.data("active-tab", $(this).data("tab"));
        });
        
        // Initial calculation for inline if fields have values
        $(".km-inline-wrapper").each(function() {
            var $wrapper = $(this);
            var hasIndustry = $wrapper.find(".km-inline-industry").val();
            var hasYears = $wrapper.find(".km-inline-years").val();
            
            if (hasIndustry && hasYears) {
                calculateInlineRefund($wrapper);
            }
        });
    }
    
    // Initialize all calculators
    initCalculators();
    
    // ========================================
    // KEYBOARD NAVIGATION (Accessibility)
    // ========================================
    
    // Allow Enter key to trigger calculate
    $(document).on("keypress", "#km_salary, #km_years, #km_industry", function(e) {
        if (e.which === 13) {
            e.preventDefault();
            $("#km_calculate_btn").click();
        }
    });
    
    $(document).on("keypress", ".km-inline-industry, .km-inline-years, #km_inline_salary", function(e) {
        if (e.which === 13 && $(this).closest(".km-inline-wrapper").length) {
            e.preventDefault();
            // Trigger claim or calculate
            $(this).closest(".km-inline-wrapper").find(".km-claim-btn").click();
        }
    });
    
});