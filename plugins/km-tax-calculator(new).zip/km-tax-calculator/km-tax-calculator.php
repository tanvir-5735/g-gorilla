<?php
/*
Plugin Name: Tax Refund Calculator
Description: Tax Refund Calculator Shortcode [km_tax_calculator] and [km_tax_calculator_inline]
Version: 1.5
Author: Md. Kamruzzaman
*/

if (!defined('ABSPATH')) {
    exit;
}

define('KM_TC_URL', plugin_dir_url(__FILE__));
define('KM_TC_VERSION', '1.5');

function km_tc_assets() {
    wp_enqueue_style('km-tc-style', KM_TC_URL . 'css/km-style.css', array(), KM_TC_VERSION);
    wp_enqueue_script('km-tc-script', KM_TC_URL . 'js/km-script.js', array('jquery'), KM_TC_VERSION, true);
}
add_action('wp_enqueue_scripts', 'km_tc_assets');

function km_tax_calculator_shortcode() {
    ob_start();
    ?>
    <div class="km-calculator-wrapper">
        <div class="km-card">

            <!-- Form Content -->
            <div class="km-content km-form-content" id="km-form-content">
                <div class="km-tabs km-regular-tabs">
                    <button type="button" class="km-tab km-regular-tab km-active" data-tab="paye">PAYE Tax Refund</button>
                    <button type="button" class="km-tab km-regular-tab" data-tab="cis">CIS Tax Refund</button>
                </div>

                <div class="km-field">
                    <label for="km_industry">Your Industry*</label>
                    <select id="km_industry" name="km_industry">
                        <option value="">Select</option>
                        <option value="construction-trades">Construction & Trades</option>
                        <option value="healthcare-care">Healthcare & Care</option>
                        <option value="recruitment">Recruitment</option>
                        <option value="travel-airlines">Travel & Airlines</option>
                        <option value="public-sector">Public Sector</option>
                        <option value="property-real-estate">Property & Real Estate</option>
                        <option value="other-industry">Other Industry</option>
                    </select>
                </div>

                <div class="km-field">
                    <label for="km_years">Number of years*</label>
                    <select id="km_years" name="km_years">
                        <option value="">Select years</option>
                        <option value="1">1 Year</option>
                        <option value="2">2 Years</option>
                        <option value="3">3 Years</option>
                        <option value="4">4 Years (Maximum)</option>
                    </select>
                </div>

                <div class="km-field">
                    <label for="km_salary">Your Salary*</label>
                    <input type="range" id="km_salary" name="km_salary" min="18000" max="150000" value="18000" step="1000">
                    <div class="km-range-footer">
                        <span id="km_salary_val">$18000</span>
                        <span class="km-range-limit">$18,000 to $150,000 Max</span>
                    </div>
                </div>

                <button type="button" id="km_calculate_btn" class="km-btn">Calculate Your Tax</button>
            </div>

            <!-- Result Content -->
            <div class="km-content km-result-content" id="km-result-content">
                <div class="result-inner">
                    <h2>Your Estimated* Refund is:</h2>
                    <div class="refund-amount" id="km_refund_amount">$0</div>
                    <p class="disclaimer">
                        <span class="info-icon">ℹ</span>
                        *Calculation is an estimation based on the average claim amount for your salary and taxable allowance. Contact us today for an exact refund figure.
                    </p>
                    <!-- ONLY CHANGE: button replaced with link -->
                    <a href="<?php echo home_url('/sign-up/'); ?>" class="km-claim-btn">Start Your Claim</a>
                    <a href="javascript:void(0);" id="km_clear_btn" class="km-clear-link">Back to Calculator</a>
                </div>
            </div>

        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('km_tax_calculator', 'km_tax_calculator_shortcode');

function km_tax_calculator_inline_shortcode() { 
    ob_start();
    ?>
    <div class="km-inline-wrapper">

        <!-- Two-column layout -->
        <div class="km-inline-container">

            <!-- Left: Calculator Form -->
            <div class="km-inline-left">
                <div class="km-card km-no-border">

                    <!-- Header Text - exactly above calculator -->
                    <div class="km-inline-header">
                        <div class="tr-cal">
                            <h2>Tax Refund Calculator</h2>
                        </div>
                        <p class="km-header-subtitle">Calculate your refund</p>
                        <p class="km-header-description">
                            Calculate your potential tax rebate in seconds. Many UK workers unknowingly overpay tax every year. Enter a few details to see how much you could claim back.
                        </p>
                    </div>

                    <!-- Tabs with unique class for inline version -->
                    <div class="km-tabs km-inline-tabs">
                        <button type="button" class="km-tab km-inline-tab km-active" data-tab="paye">PAYE Tax Refund</button>
                        <button type="button" class="km-tab km-inline-tab" data-tab="cis">CIS Tax Refund</button>
                    </div>

                    <!-- Fields -->
                    <div class="km-field">
                        <label>Your Industry*</label>
                        <select class="km-inline-input km-inline-industry">
                            <option value="">Select</option>
                            <option value="construction-trades">Construction & Trades</option>
                            <option value="healthcare-care">Healthcare & Care</option>
                            <option value="recruitment">Recruitment</option>
                            <option value="travel-airlines">Travel & Airlines</option>
                            <option value="public-sector">Public Sector</option>
                            <option value="property-real-estate">Property & Real Estate</option>
                            <option value="other-industry">Other Industry</option>
                        </select>
                    </div>

                    <div class="km-field">
                        <label>Number of years*</label>
                        <select class="km-inline-input km-inline-years">
                            <option value="">Select years</option>
                            <option value="1">1 Year</option>
                            <option value="2">2 Years</option>
                            <option value="3">3 Years</option>
                            <option value="4">4 Years (Maximum)</option>
                        </select>
                    </div>

                    <!-- Updated Salary Field - Matching the regular calculator design -->
                    <div class="km-field">
                        <label for="km_inline_salary">Your Salary*</label>
                        <input type="range" id="km_inline_salary" class="km-inline-salary" min="18000" max="150000" value="18000" step="1000">
                        <div class="km-range-footer">
                            <span id="km_inline_salary_val" class="km-inline-salary-val">$18000</span>
                            <span class="km-range-limit">$18,000 to $150,000 Max</span>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Right: Result Area - thick border, button, clear link -->
            <div class="km-inline-right">
                <div class="km-result-box">
                    <h3>Your Estimated* Refund is:</h3>
                    <div class="refund-amount km-inline-result">$0</div>
                    <p class="disclaimer-inline">
                        *Calculation is an estimation based on the average claim amount for your salary and taxable allowance. Contact us today for an exact refund figure.
                    </p>
                    <!-- ONLY CHANGE: button replaced with link -->
                    <a href="<?php echo home_url('/sign-up/'); ?>" class="km-claim-btn">Start Your Claim</a>
                    <a href="javascript:void(0);" id="km_inline_clear" class="km-clear-link">Clear Calculator</a><br>
                    <img src="http://localhost/g-gorilla/wp-content/uploads/2026/04/mascot-superhero-sitting.png" alt="Tax Refund" class="bottom-image">
                </div>
            </div>

        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('km_tax_calculator_inline', 'km_tax_calculator_inline_shortcode');
?>